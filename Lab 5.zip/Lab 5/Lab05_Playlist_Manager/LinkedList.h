// ============================================================
// Lab 05 - Individual Project: Music Playlist Manager
// Data Structure: Singly Linked List  (LinkedList.h)
//
// Problem  : A music playlist changes all the time. Users add songs
//            anywhere, remove songs, reorder them and sort them.
// Why LL   : Playlist size is not fixed. Inserting/removing in the
//            middle only changes pointers (no shifting like arrays).
// Node     : SongNode { songID, title, artist, duration, next }
// Extras   : search, total duration, save to / load from file
// ============================================================
#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>
#include <utility>
#include <cctype>
using namespace std;

struct SongNode
{
    int songID;
    string title;
    string artist;
    int duration;      // seconds
    SongNode* next;    // self-referential pointer
};

inline string ToLower(string s)
{
    for (char& c : s)
        c = (char)tolower((unsigned char)c);
    return s;
}

inline string FormatTime(int sec)
{
    int h = sec / 3600, m = (sec % 3600) / 60, s = sec % 60;
    ostringstream out;
    if (h > 0)
        out << h << ":" << setw(2) << setfill('0') << m << ":" << setw(2) << setfill('0') << s;
    else
        out << m << ":" << setw(2) << setfill('0') << s;
    return out.str();
}

inline string Fit(const string& s, size_t width)
{
    if (s.size() <= width)
        return s;
    return s.substr(0, width - 2) + "..";
}

class Playlist
{
private:
    SongNode* head;
    int count;

    SongNode* GetNodeAt(int index)
    {
        SongNode* current = head;
        for (int i = 0; i < index && current != nullptr; i++)
            current = current->next;
        return current;
    }

    void SwapData(SongNode* a, SongNode* b)
    {
        swap(a->songID, b->songID);
        swap(a->title, b->title);
        swap(a->artist, b->artist);
        swap(a->duration, b->duration);
    }

    // true if a should come AFTER b for the chosen sort field
    bool ShouldSwap(SongNode* a, SongNode* b, int by)
    {
        switch (by)
        {
        case 1:  return a->songID > b->songID;
        case 2:  return ToLower(a->title) > ToLower(b->title);
        case 3:  return ToLower(a->artist) > ToLower(b->artist);
        default: return a->duration > b->duration;
        }
    }

public:
    Playlist() { head = nullptr; count = 0; }

    int GetCount() { return count; }
    bool IsEmpty() { return head == nullptr; }
    bool IsNotEmpty() { return head != nullptr; }

    void Insert(SongNode* song)          // at head
    {
        if (song == nullptr)
            return;
        song->next = head;
        head = song;
        count++;
    }

    SongNode* Remove()                   // from head
    {
        if (IsEmpty())
            return nullptr;
        SongNode* song = head;
        head = head->next;
        song->next = nullptr;
        count--;
        return song;
    }

    void InsertAt(SongNode* song, int index)
    {
        if (song == nullptr)
            return;
        if (index < 0)
            index = 0;
        if (index > count)
            index = count;
        if (index == 0)
        {
            Insert(song);
            return;
        }
        SongNode* previous = GetNodeAt(index - 1);
        song->next = previous->next;
        previous->next = song;
        count++;
    }

    SongNode* RemoveAt(int index)
    {
        if (IsEmpty())
            return nullptr;
        if (index < 0)
            index = 0;
        if (index >= count)
            index = count - 1;
        if (index == 0)
            return Remove();
        SongNode* previous = GetNodeAt(index - 1);
        SongNode* song = previous->next;
        previous->next = song->next;
        song->next = nullptr;
        count--;
        return song;
    }

    bool Swap(int index1, int index2)
    {
        if (index1 < 0 || index1 >= count || index2 < 0 || index2 >= count)
            return false;
        if (index1 != index2)
            SwapData(GetNodeAt(index1), GetNodeAt(index2));
        return true;
    }

    // by: 1 = ID, 2 = Title, 3 = Artist, 4 = Duration
    void Sort(int by = 4)
    {
        for (SongNode* i = head; i != nullptr; i = i->next)
            for (SongNode* j = i->next; j != nullptr; j = j->next)
                if (ShouldSwap(i, j, by))
                    SwapData(i, j);
    }

    void Reverse()
    {
        SongNode* previous = nullptr;
        SongNode* current = head;
        while (current != nullptr)
        {
            SongNode* next = current->next;
            current->next = previous;
            previous = current;
            current = next;
        }
        head = previous;
    }

    void Print()
    {
        if (IsEmpty())
        {
            cout << "\nPlaylist is empty.\n";
            return;
        }
        cout << "\n" << left << setw(5) << "No." << setw(6) << "ID"
             << setw(26) << "Title" << setw(20) << "Artist" << "Duration\n";
        cout << string(64, '-') << "\n";
        int index = 0;
        for (SongNode* c = head; c != nullptr; c = c->next, index++)
            cout << left << setw(5) << index << setw(6) << c->songID
                 << setw(26) << Fit(c->title, 25) << setw(20) << Fit(c->artist, 19)
                 << FormatTime(c->duration) << "\n";
        cout << "Total songs: " << count
             << "   |   Total time: " << FormatTime(TotalDuration()) << "\n";
    }

    int TotalDuration()
    {
        int total = 0;
        for (SongNode* c = head; c != nullptr; c = c->next)
            total += c->duration;
        return total;
    }

    int FindByID(int id)
    {
        int index = 0;
        for (SongNode* c = head; c != nullptr; c = c->next, index++)
            if (c->songID == id)
                return index;
        return -1;
    }

    // case-insensitive search in title or artist
    int Search(const string& keyword)
    {
        string key = ToLower(keyword);
        int found = 0, index = 0;
        for (SongNode* c = head; c != nullptr; c = c->next, index++)
        {
            if (ToLower(c->title).find(key) != string::npos ||
                ToLower(c->artist).find(key) != string::npos)
            {
                if (found == 0)
                    cout << "\nSearch results:\n";
                cout << "  No. " << index << " | ID " << c->songID << " | "
                     << c->title << " - " << c->artist
                     << " (" << FormatTime(c->duration) << ")\n";
                found++;
            }
        }
        return found;
    }

    bool SaveToFile(const string& filename)
    {
        ofstream out(filename);
        if (!out)
            return false;
        for (SongNode* c = head; c != nullptr; c = c->next)
            out << c->songID << "|" << c->title << "|" << c->artist << "|" << c->duration << "\n";
        return true;
    }

    // returns number of songs loaded, -1 if file cannot be opened
    int LoadFromFile(const string& filename)
    {
        ifstream in(filename);
        if (!in)
            return -1;
        while (IsNotEmpty())
            delete Remove();
        string line;
        while (getline(in, line))
        {
            stringstream ss(line);
            string id, title, artist, dur;
            if (!getline(ss, id, '|') || !getline(ss, title, '|') ||
                !getline(ss, artist, '|') || !getline(ss, dur))
                continue;
            try
            {
                SongNode* s = new SongNode{ stoi(id), title, artist, stoi(dur), nullptr };
                InsertAt(s, count);
            }
            catch (...) { /* skip corrupted line */ }
        }
        return count;
    }

    Playlist(const Playlist& other)
    {
        head = nullptr; count = 0;
        for (SongNode* c = other.head; c != nullptr; c = c->next)
            InsertAt(new SongNode{ c->songID, c->title, c->artist, c->duration, nullptr }, count);
    }

    Playlist& operator=(const Playlist& other)
    {
        if (this == &other)
            return *this;
        while (IsNotEmpty())
            delete Remove();
        for (SongNode* c = other.head; c != nullptr; c = c->next)
            InsertAt(new SongNode{ c->songID, c->title, c->artist, c->duration, nullptr }, count);
        return *this;
    }

    ~Playlist()
    {
        while (IsNotEmpty())
            delete Remove();
    }
};

#endif // LINKEDLIST_H
