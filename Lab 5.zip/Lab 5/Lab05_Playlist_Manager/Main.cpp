// ============================================================
// Lab 05 - Music Playlist Manager  (Main.cpp)
// Uses the singly linked list from LinkedList.h
// ============================================================
#include <iostream>
#include <string>
#include <limits>
#include <cstdlib>
#include "LinkedList.h"
using namespace std;

// ---------------- input helpers ----------------
int ReadInt(const string& prompt)
{
    int value;
    while (true)
    {
        cout << prompt;
        if (cin >> value)
        {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return value;
        }
        if (cin.eof())
            exit(0);
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Please enter a valid number.\n";
    }
}

string ReadText(const string& prompt)
{
    string text;
    while (true)
    {
        cout << prompt;
        if (!getline(cin, text))
            exit(0);
        for (char& c : text)
            if (c == '|')
                c = '-';          // '|' is our file separator
        if (!text.empty())
            return text;
        cout << "This cannot be empty.\n";
    }
}

SongNode* ReadSong(Playlist& list)
{
    int id;
    while (true)
    {
        id = ReadInt("Song ID: ");
        if (list.FindByID(id) == -1)
            break;
        cout << "This ID already exists. Use a different ID.\n";
    }
    string title = ReadText("Title: ");
    string artist = ReadText("Artist: ");
    int minutes, seconds;
    do { minutes = ReadInt("Duration - minutes: "); } while (minutes < 0);
    do { seconds = ReadInt("Duration - seconds (0-59): "); } while (seconds < 0 || seconds > 59);
    return new SongNode{ id, title, artist, minutes * 60 + seconds, nullptr };
}

void ShowMenu()
{
    cout << "\n========================================\n";
    cout << "        MUSIC PLAYLIST MANAGER\n";
    cout << "========================================\n";
    cout << " 1. Show Playlist\n";
    cout << " 2. Add Song at Start\n";
    cout << " 3. Add Song at End\n";
    cout << " 4. Add Song at Position\n";
    cout << " 5. Remove First Song\n";
    cout << " 6. Remove Song at Position\n";
    cout << " 7. Swap Two Songs\n";
    cout << " 8. Sort Playlist\n";
    cout << " 9. Reverse Playlist\n";
    cout << "10. Search Song\n";
    cout << "11. Playlist Status\n";
    cout << "12. Save Playlist to File\n";
    cout << "13. Load Playlist from File\n";
    cout << "14. Exit\n";
}

int main()
{
    const string FILE_NAME = "playlist.txt";
    Playlist playlist;

    int loaded = playlist.LoadFromFile(FILE_NAME);
    if (loaded >= 0)
        cout << "Loaded " << loaded << " song(s) from " << FILE_NAME << ".\n";
    else
        cout << "No saved playlist found. Starting with an empty playlist.\n";

    int choice = 0;
    do
    {
        ShowMenu();
        choice = ReadInt("Enter your choice: ");

        switch (choice)
        {
        case 1:
            playlist.Print();
            break;

        case 2:
            playlist.Insert(ReadSong(playlist));
            cout << "Song added at the start.\n";
            break;

        case 3:
            playlist.InsertAt(ReadSong(playlist), playlist.GetCount());
            cout << "Song added at the end.\n";
            break;

        case 4:
        {
            int pos = ReadInt("Position (0 = first): ");
            playlist.InsertAt(ReadSong(playlist), pos);
            cout << "Song added (position adjusted if out of range).\n";
            break;
        }

        case 5:
        {
            SongNode* s = playlist.Remove();
            if (s == nullptr)
                cout << "Playlist is empty.\n";
            else
            {
                cout << "Removed: " << s->title << "\n";
                delete s;
            }
            break;
        }

        case 6:
        {
            if (playlist.IsEmpty())
            {
                cout << "Playlist is empty.\n";
                break;
            }
            int pos = ReadInt("Position to remove: ");
            SongNode* s = playlist.RemoveAt(pos);
            cout << "Removed: " << s->title << "\n";
            delete s;
            break;
        }

        case 7:
        {
            int a = ReadInt("First position: ");
            int b = ReadInt("Second position: ");
            if (playlist.Swap(a, b))
                cout << "Songs swapped.\n";
            else
                cout << "Invalid position. Nothing swapped.\n";
            break;
        }

        case 8:
        {
            cout << "Sort by: 1) ID  2) Title  3) Artist  4) Duration\n";
            int by = ReadInt("Choice: ");
            if (by < 1 || by > 4)
                cout << "Invalid sort option.\n";
            else
            {
                playlist.Sort(by);
                cout << "Playlist sorted.\n";
            }
            break;
        }

        case 9:
            playlist.Reverse();
            cout << "Playlist reversed.\n";
            break;

        case 10:
        {
            string key = ReadText("Enter title or artist to search: ");
            if (playlist.Search(key) == 0)
                cout << "No matching song found.\n";
            break;
        }

        case 11:
            cout << "Status: " << (playlist.IsEmpty() ? "EMPTY" : "NOT empty")
                 << " | Songs: " << playlist.GetCount()
                 << " | Total time: " << FormatTime(playlist.TotalDuration()) << "\n";
            break;

        case 12:
            if (playlist.SaveToFile(FILE_NAME))
                cout << "Playlist saved to " << FILE_NAME << ".\n";
            else
                cout << "Could not save the file.\n";
            break;

        case 13:
        {
            int n = playlist.LoadFromFile(FILE_NAME);
            if (n < 0)
                cout << "No saved file found.\n";
            else
                cout << "Loaded " << n << " song(s).\n";
            break;
        }

        case 14:
            if (playlist.SaveToFile(FILE_NAME))
                cout << "Playlist auto-saved. Goodbye!\n";
            else
                cout << "Goodbye! (could not save)\n";
            break;

        default:
            cout << "Invalid choice. Please select 1-14.\n";
        }
    } while (choice != 14);

    return 0;
}
