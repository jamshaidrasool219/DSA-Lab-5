#include <iostream>
#include <string>
#include <limits>
#include "LinkedList.h"
using namespace std;

// ========================================
// Helpers
// ========================================
BookNode* CreateBook(int id, string title)
{
    BookNode* book = new BookNode;
    book->bookID = id;
    book->title = title;
    book->next = nullptr;
    return book;
}

// Safe integer input (re-asks until a valid number is typed)
int ReadInt(const string& prompt)
{
    int value;
    while (true)
    {
        cout << prompt;
        if (cin >> value)
        {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return value;
        }
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Invalid input. Please enter a number.\n";
    }
}

BookNode* ReadBook()
{
    int id = ReadInt("Enter Book ID: ");
    string title;
    cout << "Enter Book Title: ";
    getline(cin, title);
    return CreateBook(id, title);
}

void ShowMenu()
{
    cout << "\n========================================\n";
    cout << "LIBRARY BOOK COLLECTION SYSTEM\n";
    cout << "========================================\n";
    cout << "1. Display All Books\n";
    cout << "2. Insert Book at Head\n";
    cout << "3. Remove Book from Head\n";
    cout << "4. Insert Book at Index\n";
    cout << "5. Remove Book at Index\n";
    cout << "6. Swap Books\n";
    cout << "7. Sort Books by ID\n";
    cout << "8. Reverse Book Collection\n";
    cout << "9. Check Collection Status\n";
    cout << "10. Exit\n";
}

// ========================================
// Main
// ========================================
int main()
{
    LinkedList library;
    int choice = 0;

    do
    {
        ShowMenu();
        choice = ReadInt("Enter your choice: ");

        switch (choice)
        {
        case 1:
            if (library.IsEmpty())
                cout << "\nThe collection is empty.\n";
            else
                library.Print();
            break;

        case 2:
        {
            library.Insert(ReadBook());
            cout << "Book inserted at head.\n";
            break;
        }

        case 3:
        {
            BookNode* removed = library.Remove();
            if (removed == nullptr)
                cout << "Collection is empty. Nothing to remove.\n";
            else
            {
                cout << "Removed from head: " << removed->title << endl;
                delete removed;
            }
            break;
        }

        case 4:
        {
            int index = ReadInt("Enter index to insert at: ");
            library.InsertAt(ReadBook(), index);
            cout << "Book inserted (index was adjusted if out of range).\n";
            break;
        }

        case 5:
        {
            if (library.IsEmpty())
            {
                cout << "Collection is empty. Nothing to remove.\n";
                break;
            }
            int index = ReadInt("Enter index to remove: ");
            BookNode* removed = library.RemoveAt(index);
            if (removed != nullptr)
            {
                cout << "Removed book: " << removed->title << endl;
                delete removed;
            }
            break;
        }

        case 6:
        {
            int i1 = ReadInt("Enter first index: ");
            int i2 = ReadInt("Enter second index: ");
            if (library.Swap(i1, i2))
                cout << "Books swapped.\n";
            else
                cout << "Invalid index. Swap not performed.\n";
            break;
        }

        case 7:
            library.Sort();
            cout << "Books sorted by ID (ascending).\n";
            break;

        case 8:
            library.Reverse();
            cout << "Collection reversed.\n";
            break;

        case 9:
            if (library.IsEmpty())
                cout << "Status: Collection is EMPTY.\n";
            else
                cout << "Status: Collection is NOT empty. Total books: "
                     << library.GetCount() << endl;
            break;

        case 10:
            cout << "Exiting... Goodbye!\n";
            break;

        default:
            cout << "Invalid choice. Please select 1-10.\n";
        }
    } while (choice != 10);

    return 0;
}
